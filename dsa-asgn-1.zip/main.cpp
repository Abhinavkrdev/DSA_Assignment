/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<iostream>

class Array 
{
    private:
    int capacity;
    int last_index;
    int *ptr;
    
    public:
    Array(int);
    bool isFull();
    int getEle(int);
    int count();
    ~Array();
    int FindEle(int);
};

int Array::FindEle(int Element)
{
    for(int i=0;i<=last_index;i++)
    {
        if(ptr[i]==Element)
        return i;
    
    return -1;
    }
}

Array::~Array()
{
    delete[]ptr;
}
int Array::count()
    {
      return last_index+1;
    }
int Array::getEle(int idx)
{
    if(idx>=0&&idx<<last_index)
    {
        return ptr[idx];
    }
    else
    {
        std::cout <<"Invalid Index"<<std::endl;
        return -1;
    }
}

bool Array::isFull()
{
  return last_index==capacity-1;
}

Array::Array(int cap)
{
    capacity=cap;
    last_index=-1;
    ptr=new int[capacity];
}


int main()
{
    Array obj(5);
    if(obj.isFull())
     {
         std::cout<<"Array is Full";
     }
     else
        std::cout<<"Array not full"<< std::endl;
        std::cout<<obj.count();    
    return 0;
        
}
