/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include "SLL"

using namespace std;

class extension:private SinglylinkedList
{
    int countItems();
    void reverseLinkedlist();
    void reverseStack(SinglylinkedList &);
};

node* merge(node* &obj1,node* &obj2)    //Two merge two sorted linkedlist
{
    node* t1=obj1;              //assigning obj1 & obj2 to t1 & t2 repectively.
    node* t2=obj2;              //t1 & t2 point to two sorted linkedlist.
    node* dummyNode=new node();  // we make one dummynode which will point to merged sorted linkedlist.
    node* t3=dummyNode;
    
    while(t1!=NULL && t2!=NULL)
    {
        if(t1->item < t2->item)
        {
            t3->next=t1;
            t1=t1->next;
        }
        else
        {
            t3->next=t2;
            t2=t2->next;
        }
        t3=t3->next;
    }
    
    while(t1!=NULL)
    {
        t3->next=t1;
        t1=t1->next;
        t3=t3->next;
    }
   
    while(t2!=NULL)
    {
        t3->next=t2;
        t2=t2->next;
        t3=t3->next;
    }
    return t3->next;
}

//https://www.youtube.com/watch?v=n5_9DMCX0Yk&t=122s    refer this if doubt.
int is_cycle(SinglylinkedList &obj)
{
    node* t1,*t2;
    t1=obj.getstartptr();
    t2=t1;
    do                     // As initailly t1=t2 so we applied do while instead of while loop.
    {
      if(t1==NULL)         // here we are keeping t1 ahead of t2.
        return 0;          // checking t1 & t1->next don't have null in it.
      if(t1->next!=NULL)
        t1=t1->next->next;
      else
        t2=t2->next;       // As we are keeping t1 ahead so no need of same checks for t2 as they already 
    }while(t1!=t2) ;        // checked for t1 cases.
    return 1;              // When t1=t2 then cycle is present so we return 1.
}
int length_of_cycle(SinglylinkedList &obj)
{
    int count=1;                           //if is_cycle is true then must have at lest one cycle.
    node *t1,*t2;
    if(is_cycle(obj))                      //if is_cycle is true then only lenght calculated.
    {
       t2=t1=obj.getstartptr();
       do
       {
           t1=t1->next->next;
           t2=t2->next;
       }while(t1!=t2);                      // Here t1 become equal to t2.
       while(t1->next!=t2)
       {
           count++;
           t1=t1->next->next;
       }
        return count;                        //Will return length of cycle.
    }
    return 0;
}

int Sorting(SinglylinkedList &obj)    //SelfMade function
{
    node* t1,*t2;
    int temp;
    t1=obj.getstartptr();
    t2=t1->next;
    
    if(t1!=NULL)
    {
      while(t2!=NULL)
      {
        if(t1->item > t2->item)
        {
            temp=t2->item;
            t2->item=t1->item;
            t1->item=temp;
        }
        t1=t2;
        t2=t2->next;
      }
      return 1;
    }
    return 0;
}
/*
void extension::reverseLinkedlist()
{
    node* t=SinglylinkedList::getstartptr();
    while(t->next!=NULL)
     
    node* t1=start->next;
}*/
void extension::reverseStack(SinglylinkedList &obj)     //Method to reverse linkedlist
{
      node *t1,*t2,*top;            
      t2=NULL;
      top=obj.getstartptr();
      do
      {
        t1=top;
        top=top->next;
        t1->next=t2;          //This will make the pointer to point on previous node(to reverse stack)
        t2=t1;
      }while(top->next!=NULL);
      top->next=t1;
}

node* middleNode(SinglylinkedList &obj)      //Selfmade function
{
    node *t1,*t2;
    t2=t1=obj.getstartptr();
    while(t1!=NULL)                         //when t1=NULL it reaches the last node so we ll return t2. 
    {
        t1=t1->next->next;                  //t1 is faster than t2
        t2=t2->next;
    }
    return t2;
}
int extension::countItems()
{
    node* temp=SinglylinkedList::getstartptr();
    int count=0;
    while(temp!=NULL)
    {
        count++;
      temp=temp->next;
    }
    return count;
}

int main()
{
    printf("Hello World");

    return 0;
}
