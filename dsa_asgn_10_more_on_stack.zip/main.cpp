/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdio.h>

using namespace std;

struct node{
    int item;
    node* next;
};

class stack
{
    private:
      node* top;
    public:
      stack();
      void push(int data);
      int peek();
      void pop();
      ~stack();
      void reverseStack();
};

int length(int x)
{
    int count=0;
    while(x)
    {
        x/=10;
        count++;
    }
    return count;
}

bool isPalindrome(int x)
{
    stack s;
    int l=length(x);
    int i=l/2;            //In stack we are pushing only 50% of data.
    while(i)
    {
        s.push(x%10);
        x/=10;
        i--;
    }
    if(l%2==0)
      x/=10;               //if length is even then reduce number by 1 digit.
    
    while(x)
    {
        if(x%10==s.peek())   //when 
        {
            s.pop();
            x/=10;
        }
        else
        return false;
    }
     return true;
}

void stack::reverseStack()     //Method to reverse linkedlist
{
      node *t1,*t2;            
      t2=NULL;
      do
      {
        t1=top;
        top=top->next;
        t1->next=t2;          //This will make the pointer to point on previous node(to reverse stack)
        t2=t1;
      }while(top->next!=NULL);
      top->next=t1;
}

stack::~stack()
{
    while(top)      //pop until top do not contains NULL.
       pop();
}
void stack::pop()
{
    node *r;
   if(top==NULL)
    {
      cout << "\nStack UnderFlow";
    }
    else
    {
       r=top;
       top=top->next;
       delete r;
    } 
}

int stack::peek()
{
    if(top==NULL)
    {
      cout << "\nStack is Empty";
      return -1;
    }
    else
    {
      return top->item;
    }
}
stack::stack()
{
    top=NULL;
}
void stack::push(int data)
{
  node* n;
  n=new node;
  n->item=data;
  n->next=top;
  top=n;
}

int main()
{
    cout<<"Hello World";

    return 0;
}
