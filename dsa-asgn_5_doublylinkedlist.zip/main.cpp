/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct node
{
  int item;
  node *next;
  node *start;
  node *prev;
};

class DoublyLL
{
  
  private:
  node *start;
  public:
  DoublyLL();
  void InsertAtStart(int);
  void InsertAtEnd(int);
  node *SearchNode(int);
  void InsertData(node *,int);
  void deletefirstNode();
  void deletelastNode();
  void deleteNode(node *);
  ~DoublyLL();
};

DoublyLL::~DoublyLL()
{
     while(start)
     deletefirstNode();
}

void DoublyLL::deleteNode(node *ptr)
{
    if(ptr->prev)
      ptr->prev->next=ptr->next;
    else
      start=ptr->next;
    if(ptr->next)
      ptr->next->prev=ptr->prev;
    else
      ptr->prev->next=NULL;
    delete ptr;
}

void DoublyLL::deletelastNode()
{
    node *t;
    t=start;
    while(t->next!=NULL)
    {
        t=t->next;
    }
    if(t->prev)
      t->prev->next=NULL;
    else
      start=NULL; 
    delete t;
}

void DoublyLL::deletefirstNode()
{
    if(start)
    {
        node *t;
        t=start;
        start=start->next;
        delete t;
    }
}

void DoublyLL::InsertData(node *temp,int data)
{
    if(temp)
    {
      node *n=new node;
      n->item=data;
      n->prev=temp;
      n->next=temp->next;
      if(temp->next)           //temp ke next me NULL ni hona chahye.
          temp->next->prev=n;  //temp ke next ke prev me n assign hoga.
      temp->next=n;  
    }
}
node *DoublyLL::SearchNode(int data)
{
    node *t;
    t=start;
    while(t!=NULL)
    {
        if(t->item==data)
        return t;
        t=t->next;
    }
    return t;
}

DoublyLL::DoublyLL()
{
   start= NULL;
}

void DoublyLL::InsertAtStart(int data)
{
    node *n=new node;
    n->item=data;
    n->next=start;
    n->prev=NULL;
    start=n;
}

void DoublyLL::InsertAtEnd(int data)
{
    node *n=new node;
    node *t;
    n->item=data;
    n->next=NULL;
    t=start;
    while(t->next!=NULL)
    {
        t=t->next;
    }
    n->prev=t;
    t->next=n;
}
int main()
{
    printf("Hello World");

    return 0;
}
