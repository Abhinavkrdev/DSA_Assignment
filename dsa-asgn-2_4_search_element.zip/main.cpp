/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void Search(int b[],int c,int n)
{
    int Element=n;
    for(int i=0;i<c;i++)
    {
        if(b[i]==Element)
        printf("Element found at posistion %d",i);
    }
    
}

int main()
{
    int i,a[3],n;
    printf("Enter Element to be searched ");
    scanf("%d",&n);
    printf("Enter Numbers of array\n");
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
    }
    Search(a,3,n);

    return 0;
}