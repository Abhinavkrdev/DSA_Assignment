/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// C++ Program to demonstrate the
// functioning of a friend class
#include<bits/stdc++.h>

using namespace std;

void Print(int);
void Reverseprint(int);
void PrintOddNaturalNo(int);
void ReverseprintOddNaturalNo(int);
void PrintEvenNaturalNo(int);
void ReverseprintEvenNaturalNo(int);
void PrintsquareofNNaturalno(int);
void PrintReverseSquareofNNaturalno(int);

int main()
{
    int a,b,c,d,e,f,g,h;
    cout << endl << "Print reverse of Sqaure's first N natural number ";
    cin >> h;
    PrintReverseSquareofNNaturalno(h);
    cout << endl << "Print Sqaure's first N natural number ";
    cin >> g;
    PrintsquareofNNaturalno(g);
    cout << endl << "Print first N Even natural number in reverse order ";
    cin >> f;
    ReverseprintEvenNaturalNo(f);
    cout << endl << "Print first N Even natural number ";
    cin >> e;
    PrintEvenNaturalNo(e);
    cout << endl << "Print first N odd natural number in reverse order ";
    cin >> d;
    ReverseprintOddNaturalNo(d);
    cout << endl << "Print first N odd natural number ";
    cin >> c;
    PrintOddNaturalNo(c);
    cout << endl << "Print first N natural number ";
    cin >> a;
    Print(a);
    cout << endl << "Print first N natural number in reverse order ";
    cin >> b;
    Reverseprint(b);
    return 0;
}

void PrintReverseSquareofNNaturalno(int N)
{
    if(N > 0)
    {
      cout << N*N << " ";
      PrintReverseSquareofNNaturalno(N-1);
    } 
}

void PrintsquareofNNaturalno(int N)
{
    if(N > 0)
    { 
      PrintsquareofNNaturalno(N-1);
      cout << N*N << " ";
    } 
}

void ReverseprintEvenNaturalNo(int N)
{
    if(N > 0)
    {
      cout << 2*N;
      ReverseprintEvenNaturalNo(N-1);
    }
}

void PrintEvenNaturalNo(int N)
{
    if(N > 0)
    {
      PrintEvenNaturalNo(N-1);
      cout << 2*N;
    } 
}

void ReverseprintOddNaturalNo(int N)
{
    if(N > 0)
    {
      cout << 2*N-1;
      ReverseprintOddNaturalNo(N-1);
    }
}
void PrintOddNaturalNo(int N)
{
    if(N > 0)
    {
      PrintOddNaturalNo(N-1);
      cout << 2*N-1;
    } 
}
void Print(int N)
{
    if(N > 0)
    { 
      Print(N-1);
      cout << N;
    } 
}

void Reverseprint(int N)
{
    if(N)
    {
      cout << N;
      Reverseprint(N-1);
    } 
}



