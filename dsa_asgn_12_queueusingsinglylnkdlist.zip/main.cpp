/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>

using namespace std;

struct node
{
    int item;
    node *next;
};

class Queue
{
    private:
    node* front;
    node* rear;
    
    public:
    Queue();
    ~Queue();
    void InsertAtRear(int);
    bool isEmpty();
    node* getRear();
    node* getFront();
    void delAtFront();
    int count();
};

Queue::~Queue()               //Destructor to dellocate memory
{
    while(isEmpty())
      delAtFront();
}

void Queue::delAtFront()     //Method to delete front 
{                            
    node *r;
    if(isEmpty())
    {
        r=front;
        front=front->next;
        if(front==NULL)
          rear=NULL;
        delete r;
    }
}

int Queue::count()                // Count no. of elements in queue
{
    node *t;
    int c=0;
    t=front;
    while(t)
    {
        c++;
        t=t->next;
    }
    return c;
}

bool Queue::isEmpty()
{
    return rear==NULL;
}

node* Queue::getRear()
{
  return rear;
}

node* Queue::getFront()
{
  return front;
}

void Queue::InsertAtRear(int data)           //Insert element at rear of queue.
{
    node* n=new node;
    n->item=data;
    n->next=NULL;
    if(!isEmpty())
      front=rear=n;
    else
    {
       rear->next=n;
       rear=n;
    }
}
Queue::Queue()                          //Constructor
{
    front=NULL;
    rear=NULL;
}

int main()
{
    printf("Hello World");

    return 0;
}
