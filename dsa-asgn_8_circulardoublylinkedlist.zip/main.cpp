/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

using namespace std;

struct node
{
    node *prev;
    int item;
    node *next;
};
 class CDLL
{
   private:
   node *start;
   public:
   CDLL();
   void InsertAtFirst(int);
   void InsertAtLast(int);
   node *SearchNode(int);
   void InsertAfter(node*,int);
   void DeleteFirst();
   void Deletelast();
   void DeleteNode(node*);
   ~CDLL();
};

CDLL::~CDLL()
{
    while(start)
    DeleteFirst();
}
void CDLL::DeleteNode(node* ptr)
{
    if(ptr)
    {
      if(start->prev==start)   //When only one node is present.
         {
            delete start;
            start=NULL;
         }  
         else
         {
            ptr->prev->next=ptr->next;
            ptr->next->prev=ptr->prev;
            if(start==ptr)    //when we have to delete first node of multi node linked list.
            {
               start=start->next;
            }
         }      
          delete ptr;
    }
}

void CDLL::Deletelast()
{
    node *r;
    if(start)
    {
        if(start->prev==start)
        {
            delete start;
            start=NULL;
        }
        else
        {
            r=start->prev;
            r->prev->next=start;
            r=r->prev;
            delete r;
        }
    }
}

void CDLL::DeleteFirst()
{
    if(start)
    {
      node *r;
      r=start;
      r->next->prev=r->prev;
      r->prev->next=r->next;
      if(start->next==start)
        start=NULL; 
      else
        start=r->next;
      delete r;
    }
}

void CDLL::InsertAfter(node* ptr,int data)
{
    if(ptr)
    {
        node *n=new node;
        n->item=data;
        n->prev=ptr;
        n->next=ptr->next;
        ptr->next=n;
        ptr->next->prev=n;
    }
}
node* CDLL::SearchNode(int data)
{
    node *t;
    t=start;
    if(t)
    {
      do
      {
          if(t->item==data)
          return t;
           t=t->next;
      }while(t!=start);
    }
    return NULL;
}
CDLL::CDLL()
{
    start=NULL;
}

void CDLL::InsertAtLast(int data)
{
    node *n=new node;
    n->item=data;
    if(start!=NULL)
    {
      n->next=start;
      n->prev=start->prev;
      n->prev->next=n;
      n->next->prev=n;
    }
    else
    {
       n->prev=n;
       n->next=n;
       start=n;
    }
}

void CDLL::InsertAtFirst(int data)
{
    node *n=new node;
    n->item=data;
    if(start!=NULL)
    {
      n->prev=start->prev;
      n->next=start;
      n->next->prev=n;
      n->prev->next=n;
      start=n;
    }
    else
    {
       n->prev=n;
       n->next=n;
       start=n;
    }
}

int main()
{
    printf("Hello World");

    return 0;
}
