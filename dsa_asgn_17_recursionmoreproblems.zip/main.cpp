/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<bits/stdc++.h>
using namespace std;

int Sum(int);
int factorial(int);
int SumofNOddNaturalNo(int);
int SumofNEvenNaturalNo(int);
int SumofSqNNaturalNo(int);
int Sumofdigits(int);
void Printbinary(int);
int Getfibdata(int);
int GetHCF(int,int);
int CalculateXpwrY(int,int);

int CalculateXpwrY(int x,int y)
{
    if(y==0)
        return 1;
    else if(y>0)
        return CalculateXpwrY(x,y-1)*x;
    else
        return CalculateXpwrY(x,y+1)*1/x;
}

int GetHCF(int a,int b)    //Method to get HCF of two number.
{
    if(a==0)
        return b;
    if(b==0)
        return a;
    if(a>=b)
        return GetHCF(a%b,b);
    if(a<b)
        return GetHCF(a,b%a);
    return 0;
}

int Getfibdata(int n)        //Method to get nth term of fibbonaci series.
{
    if(n==0|n==1)      // Base condition 
      return n;
    return Getfibdata(n-1)+Getfibdata(n-2);   //n-1 & n-2 add up to make n in 
}

void Printbinary(int num)   //Method to print binary of given decimal number.
{
    int temp;
    if(num)
    {
      temp= num%2;
      Printbinary(num/2);
      cout << temp;
    }
}

int Sumofdigits(int num)    //Method to get sum of digits of anumber.
{
    int temp,sum;
    if(num)
    {
    temp=num%10;
    sum=temp + Sumofdigits(num/10);
    return sum;
    }
    return 0;
}

int factorial(int num)     //To get factorial of a number.
{
    int fun;
    if(num>0)
    {
        if(num==1)        //Base Condition
        return 1;
      fun=num*factorial(num-1);
      cout << fun << " ";
      return fun;
    } 
    return 1;
}

int SumofSqNNaturalNo(int num)    //Recursive fun to calculate sum square of first N natural number.
{
    if(num)
    {
        num = num*num + SumofSqNNaturalNo(num-1);
        cout << num << " ";
    }
  return num;
}

int SumofNEvenNaturalNo(int num)    //Recursive fun to calculate sum of first N natural number.
{
    if(num)
    {
      int sum;
      sum =2*num + SumofNEvenNaturalNo(num-1);  
      return sum;
    }
    //if(num==1)   // Method of sir
      //return 2;
    //int sum = 2*num + SumofNEvenNaturalNo(num-1);  
    //return sum;
  return 0;
}

int SumofNOddNaturalNo(int num)    //Recursive fun to calculate sum of first N natural number.
{
    if(num)
    {
      int sum;
      sum =2*num-1 + SumofNOddNaturalNo(num-1);  
      return sum;
    }
    //if(num==1)   // Method of sir
      //return 1;
    //int sum = 2*num-1 + SumofNOddNaturalNo(num-1);  
    //return sum;
  return 0;
}

int Sum(int num)    //Recursive fun to calculate sum of first N natural number.
{
    if(num)
    {
        num = num + Sum(num-1);
        cout << num << " ";
    }
  return num;
}

int main()
{
    int N,a,b,c,d;
    cout << "Enter the Number ";
    cin >> N;
    cout << "Enter two number to get HCF ";
    cin >> a;
    cin >> b;
    cout << "Enter two number to get Calculate x to power y ";
    cin >> c;
    cin >> d;
    //cout << Sum(N);
    cout << CalculateXpwrY(c,d);
    //cout << GetHCF(a,b);
    //cout << Getfibdata(N);
    //Printbinary(N);
    //cout << Sumofdigits(N);
    //cout << factorial(N);
    //cout << SumofSqNNaturalNo(N);
    //cout << SumofNEvenNaturalNo(N);
    //cout << SumofNOddNaturalNo(N);
    return 0;
}




