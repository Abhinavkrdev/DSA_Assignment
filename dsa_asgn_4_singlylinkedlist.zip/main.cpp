/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

struct node
{
    int item;
    node *next;
};

class SinglylinkedList
{
    private:
    node *start;
    public:
    SinglylinkedList();   
    void InsertAtStart(int);
    void InsertAtLast(int);
    node* SearchNode(int);
    void InsertAfter(node *,int);
    void deleteFirst();
    void deletelast();
    void deleteNode(node *);
    ~SinglylinkedList();
};
SinglylinkedList::~SinglylinkedList()
{
    while(start)
      deleteFirst();
}
void SinglylinkedList::deleteNode(node *temp)
{
   node *t;
   if(start==NULL)
     cout<<"\nUnderflow";
   else
        if(temp)
        {
            if(start==temp)
            start=temp->next;
            delete temp;
        }
        else
        {
            t=start;
            while(t->next!=temp)
              t=t->next;
            t->next=temp->next;
            delete temp;
        }
}

void SinglylinkedList::deletelast()
{
    node *t;
    if(start==NULL)
    {
        cout<<"Underflow";
    }
    else if(start->next==NULL)
    {
        delete start;
    }
    else
    {
        t=start;
        while(t->next->next==NULL)
          t=t->next;
          delete t;
          t->next=NULL;
    }
}
void SinglylinkedList::deleteFirst()
{
    if(start)
    {
        node *t;
        t=start;
        start=start->next;
        delete t;
    }
}
void SinglylinkedList::InsertAfter(node *ptr,int data)
{
    node *n=new node;
    n->item=data;
    n->next=ptr->next;
    ptr->next=n;
}
void SinglylinkedList::InsertAtStart(int data)
{
    node *n=new node;
    n->item=data;
    n->next=start;
    start=n;
}

void SinglylinkedList::InsertAtLast(int data)
{
    
    node *n=new node;
    node *t;
    n->item=data;
    n->next=NULL;
    while(t->next!=NULL)
    {
        t=t->next;
    }
    t->next=n;
}

node* SinglylinkedList::SearchNode(int data)
{
    node *t;
    t=start;
    while(t!=NULL)
    {
        if(t->item==data)
        return t;
        t=t->next;
    }
    return t;
}

SinglylinkedList::SinglylinkedList()
    {
        start=NULL;
    }

int main()
{
    cout<<"Hello World";

    return 0;
}