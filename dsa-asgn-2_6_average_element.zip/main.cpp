/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void Sum(int b[],double c)
{
    double sum=0;
    for(int i=0;i<c;i++)
    {
        sum=sum+b[i];
    }
    double Avg=sum/c;
    printf("Avg of elements of array is %lf",Avg);
}

int main()
{
    int i,a[3],n;
    printf("Enter Number\n");
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
    }
    Sum(a,3);


    return 0;
}