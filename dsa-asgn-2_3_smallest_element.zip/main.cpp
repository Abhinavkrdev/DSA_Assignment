/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void Smallest(int b[],int c)
{
    int min=b[0];
    for(int i=1;i<c;i++)
    {
        if(b[i]<min)
            min=b[i];
    }
    printf("%d",min);
}

int main()
{
    int i,a[3],n;
    printf("Enter Number\n");
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
    }
    Smallest(a,3);

    return 0;
}

