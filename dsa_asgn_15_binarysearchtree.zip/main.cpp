/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

struct node
{
  int item;
  node* left;
  node* right;
};

class BST
{
    private:
    node *root;
    // we are making it protected so that users can't access it.                                               
    protected:                                    //                  BST
    void preorderrec(node*);                       //                  4
    void inorderrec(node*);                        //              2       3
    void postorderrec(node*);                      //            4   5   6   7
    node* deleteNode(node*,int);
    
    public:                                   
    BST();
    bool isEmpty();
    void Insert(int);
    void preorder();
    void postorder();
    void inorder();
    void del(int);
};

node* BST::deleteNode(node* ptr,int data)
{
    if(ptr==NULL)                               //                        BST 
      return NULL;                              //                        60
    if(data < ptr->item)                        //                40              90
      ptr->next=deleteNode(ptr->left,data)      //            20     50        80     100
    else if(data > ptr->item)                   //                          70    85
      ptr->right=deleteNode(ptr->right,data)    //                       65
    else                                        // When element found then this case hit.    
    {                                           // 
        //No child                              // 
        if(ptr->left==NULL && ptr->right==NULL) // 
        {                                       // 
            delete ptr;                         // 
            return NULL;                        //
        }                                       //
        //Single child
        if(ptr->left==NULL || ptr->right==NULL)
        {
            node* child=ptr->left?ptr->left:ptr->right;     // conditional operator
            delete ptr;
            return child;
        }
        //Two child
        
    }
    
}

void BST::del(int data)
{
    root=deleteNode(root,data);
}

void BST::postorder()     // We are doing preorder travering by recursion.
{
    postorderrec(root);
}

void BST::postorderrec(node* ptr)  // Used to print node data in sequence  4(left)5(right)2(root) 6(left)7(right)3(root) 1(root)
{                                //    452 673 1
    if(ptr)
    {
        postorderrec(ptr->left);
        postorderrec(ptr->right);
        cout << ptr->item;
    }
}

void BST::inorder()     //we are doing this becoz we don't want to alter root data.so we took ptr as pointer & 
{                       // and esse ye hoga jab koi user inorder ko call krega to root pass krne ki jarurat ni pdegi usko arg me.
    inorderrec(root);
}

void BST::inorderrec(node* ptr)    // Used to print node data in sequence  4(left)2(root)5(right) 1(root) 6(left)3(root)7(right)
{                                //  425 1 637
    if(ptr)
    {
        inorderrec(ptr->left);
        cout << ptr->item;
        inorderrec(ptr->right);
    }
}

void BST::preorder()
{
    preorderrec(root);
}

void BST::preorderrec(node* ptr)    // Used to print node data in sequence 1(root) 2(root)4(left)5(right) 3(root)6(left)7(right)
{                                 //  1 245 367    
    if(ptr)
    {
        cout << ptr->item;
        preorderrec(ptr->left);
        preorderrec(ptr->right);
    }
}

void BST::Insert(int data)
{
    node* ptr;            // For traversing we made ptr pointer. 
    node* n=new node;     // New node created for to Insert.
    n->left=NULL;         // Note: Insertion will be done always as a leaf node.so, left=NULL & right=NULL.
    n->item=data;         // Data which is required to be inserted.
    n->right=NULL;
    if(root==NULL)        
      root=n;             // When root is NULL make it as a first node;
    else  
    {
       while(n->item!=ptr->item)     // Continue searching untill item of ptr & n node become samebeocz duplicate value are not allowed.
       {
           if(n->item < ptr->item)   // Going towards left.
           {
               if(ptr->left!=NULL)
                   ptr=ptr->left;    // traversing
               else 
                   ptr->left=n;      // if left is NULL then insert that new node.
               break;
           }
           else
           {
               if(ptr->right!=NULL)   // Going towards right.
                   ptr=ptr->right;
               else 
                   ptr->right=n;
               break;
           }
       }
       if(n->item==ptr->item)        // when already exiting item & new item(data) are same the delete new node becoz duplicate entries are not allowed.
         delete n;
    }
}

bool BST::isEmpty()
{
    return root==NULL;
}

BST::BST()
{
    root=NULL;
}

int main()
{
    cout<<"Hello World";

    return 0;
}

