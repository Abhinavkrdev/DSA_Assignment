/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

struct node
{
    int item;
    node* next;
    int pno;
};

class PriorityQueue
{
  private:
  node* start;
  public:
  PriorityQueue();
  ~PriorityQueue();
  void Insert(int,int);
  void del();  
  int GetHighestPriorityElement();
  int GetHighestPriorityNo();
  bool isEmpty();
};
//Note: PriorityQueue ek aise linkedlist hai jisme nodes priority order ke descending order me arranged hai.

bool PriorityQueue::isEmpty()
{
    return  start==NULL;
}

PriorityQueue::~PriorityQueue()
{
     while(start)
        del();
}

int PriorityQueue::GetHighestPriorityElement()
{
   if(start)
       return start->item;
   return -1;
}

int PriorityQueue::GetHighestPriorityNo()
{
   if(start)
       return start->pno;
   return 0;
}

PriorityQueue::PriorityQueue()
{
    start=NULL;
}

void PriorityQueue::Insert(int data,int num)
{
    node *t;
    node *n=new node;
    n->item=data;
    n->pno=num;
    if(start==NULL)
    {
       n->next=NULL;
       start=n;
    }
    else if(start->pno<n->pno)
    {
        start->next=NULL;
        n->next=start;
        start=n;
    }
    else
    {
        t=start;
        while(t->next==NULL)
         {
            if(t->pno>=n->pno)
              t=t->next;
            else
            break;
         }
         n->next=t->next;
         t->next=n;
    }
}

void PriorityQueue::del()
{
    node *r=new node;
    
    if(start)
    {
        r=start;
        start=start->next;
        delete r;
    }
}




int main()
{
    cout<<"Hello World";

    return 0;
}