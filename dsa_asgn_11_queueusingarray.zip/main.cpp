/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>

using namespace std;

class Queue
{ 
  private:
  int capacity;
  int front,rear;
  int *ptr;
  
  public:
  Queue(int);
  ~Queue();
  Queue(Queue &);
  bool isFull();
  bool isEmpty();
  int getRear();
  int getFront();
  void Insert(int);
  void del(int);
  int Count();
  Queue& operator=(Queue &);
  
};

int Queue::Count()
{
    if(isEmpty())
        return 0;
    else if(front < rear)
        return rear-front+1;           // when 
    else  
        return capacity-front+rear+1;
}

Queue& Queue::operator=(Queue &Q)   //When Q3 is not declared while intialisation later ww intialize it Q3=Q1
{                                   // then this operator overloading will be used to intilaze Q3.
    capacity=Q.capacity;
    rear=Q.rear;
    front=Q.front;
    if(ptr=NULL)                //If the pointer ptr is NULL then delete it
       delete []ptr;            
    int n=Q.Count();
    int i=Q.front;
    while(n)
    {
        ptr[i]=Q.ptr[i];
        if(i==capacity-1)
            i=0;
        else
            i++;
        n--;
    }
    return Q;
}

Queue::Queue(Queue &Q)           //While intialisation when Q2=Q1, we need to deep copy elements 
{
    capacity=Q.capacity;
    rear=Q.rear;
    front=Q.front;
    ptr=new int[capacity];
    int n=Q.Count();
    int i=Q.front;
    while(n)                     //TO Copy queue data from Q to current queue.
    {
        ptr[i]=Q.ptr[i];         //Jo data queue me hoga wo current queue me copy ho jyega it will not
        if(i==capacity-1)        //check the Empty places
          i=0;                   //This is the case when element is at right most position and next element is at 0.
         else
           i++;
        n--;                
    }
}

//Q. Destrutor to deallocate the memory
Queue::~Queue()
{
    delete []ptr;
}

Queue::Queue(int cap)
{
    int capacity=cap;
    front=-1; 
    rear=-1;
    ptr=new int[cap];
}

int Queue::getRear()
{
    if(isEmpty())
      return ptr[rear];
    cout<<"\nQueue is Empty";
    return -1;
}

int Queue::getFront()
{
    if(isEmpty())
       return ptr[front];
    cout<<"\nQueue is Empty";
    return -1;
}

bool Queue::isFull()
{
    return front==0&&rear==capacity-1 || rear==front-1;
}

bool Queue::isEmpty()
{
    return rear==-1;
}
//Q. Insert new element at rear of Queue.                   
//Note: For insertion case sequence is important.
void Queue::Insert(int data)
{
    if(isFull())
       cout << "\nQueue Overflow";
    else if(isEmpty())
   {
       front=rear=0;         //will make front & rear both as 0 and insert in rear
       ptr[rear]=data;
   }
    else if(rear=capacity-1)      //case when some elements are deleted from queue from front
   {
       rear=0;
       ptr[rear]=data;
   }
   else 
   {
       rear++;            //When two elements are deleted then insertion done at 0 then this ll invoke.
       ptr[rear]=data;
   }
}
//Q. Method to delete front of the Queue.
//Note: For deletion case sequence is important. 
void Queue::del(int data)
{
    if(isEmpty())                //When queue is totally empty.
        cout <<"\nQueue Underflow";
    else if(rear==front)         //queue has only one element where rear=front after deletion we put -1 in B/R.
        rear=front=-1;
    else if(front==capacity-1)   //when front is at last & rear=0 after del front,put front=0; 
        front=0;
    else 
       front++;                 //Normal case after deletion front increase by +1.
}

int main()
{
     cout << "Hello world";

    return 0;
}


