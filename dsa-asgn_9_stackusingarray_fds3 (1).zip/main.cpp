/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include "DS3_Arrya_data_structure"
using namespace std;

class Stack:private Array
{
  public:
  Stack(int);
  Stack(Stack &);
  void push(int);
  int peek();
  void pop();
  ~Stack();
  virtual bool isFull();
  virtual bool isEmpty();
  int getStackSize();
  void reverseStack(Stack &);
  void operator=(Stack &);
};
void Stack::operator=(Stack &s)
{
    Array::operator=(s);
}

int Stack::getStackSize()
{
    return Array::getCapacity();
}

void Stack::reverseStack(Stack &s1)
{
    Stack s2(s1.getStackSize());
    while(!s1.isEmpty())
    {
        s2.push(s1.peek());
        s1.pop();
    }
    s1=s2;
}

bool Stack::isEmpty()
{
    return Array::isEmpty();
}
bool Stack::isFull()
{
    return Array::isFull();
}
Stack::~Stack()
{}
Stack::Stack(Stack &S):Array(S)
{}
void Stack::pop()
{
    if(isEmpty())
    cout <<"Stack Underflow";
    else
    del(count()-1);
}
int Stack::peek()
{
    if(!isEmpty())
        return get(count()-1);  // By this we will get the last element & we returned it.
    else                        // hm argmnt me count bhi de skte h i.e func.
       cout <<"Stack is Empty";
    return 0;
}

void Stack::push(int data)
{
    if(isFull())
    cout << "Stack Overflow";
    else
    append(data);
}

Stack::Stack(int cap):Array(cap)  //Child class ka constructor parent class ke constructor ko call krta h.
{}                      //Stack is child class & Array is parent class.

void popFromStack(Stack &s,Stack &minStack)
{
    s.pop();
    minStack.pop();
}
void pushInStack(Stack &s,Stack &minStack, int data)  //In this we are accessing both object
{
    s.push(data);
    if(minStack.isEmpty())
        minStack.push(data);
    else
    {
        if(data>minStack.peek())
           minStack.push(minStack.peek());
        else
           minStack.push(data);
    }       
}
int main()
{
    Stack s(10);
    Stack minStack(5);
    s.push(10);
    s.push(15);
    s.push(20);
    s.push(25);
    s.push(30);
    cout<<endl<<s.peek();
    s.reverseStack(s);
    cout<<endl<<s.peek();
    
    pushInStack(s,minStack,50);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    pushInStack(s,minStack,40);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    pushInStack(s,minStack,60);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    pushInStack(s,minStack,70);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    pushInStack(s,minStack,30);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    cout<<endl<<"Poping Start";
    popFromStack(s,minStack);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    popFromStack(s,minStack);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    popFromStack(s,minStack);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    popFromStack(s,minStack);
    cout<<endl<<"Current minimum Value is "<<minStack.peek();
    
    return 0;
}
