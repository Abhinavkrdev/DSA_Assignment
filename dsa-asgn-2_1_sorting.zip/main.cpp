/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void sort(int b[],int c)
{
    //printf("here line 15");
    for(int i=0;i<c;++i)
    {
        for(int j=i+1;j<c;++j)
        {
            if(b[i]>b[j])
            {
                int a=b[j];
                b[j]=b[i];
                b[i]=a;
            }
        }
    }
    for(int i=0;i<c;i++)
    {
        printf("%d,",b[i]);
    }
}

int main()
{
    int i,a[10],n;
    printf("Enter Number");
    
    for(i=0;i<10;i++)
    {
        scanf("%d",&a[i]);
        //printf("43");
    }
    //printf("45");
    sort(a,10);
    
    return 0;
}