/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void Sum(int b[],int c)
{
    int temp=b[c-1];
    for(int i=c-1;i>0;i--)
    {
       b[i]=b[i-1];
       
    }
    b[0]=temp;
    for(int j=0;j<c;j++)
    printf("%d",b[j]);
    
}

int main()
{
    int i,a[6],n;
    printf("Enter Number\n");
    for(i=0;i<6;i++)
    {
        scanf("%d",&a[i]);
    }
    Sum(a,6);


    return 0;
}