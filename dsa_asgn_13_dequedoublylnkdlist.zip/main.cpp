/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

struct node
{
  int item;
  node *next;
  node *prev;
};

class Deque
{
    private:
    node *front,*rear;
    public:
    Deque();
    bool isEmpty();
    void InerstAtFront(int);
    void InerstAtRear(int);
    void DeleteAtFront();
    void DeleteAtRear();
    node* getFront();
    node* getRear();
    ~Deque();
};

bool Deque::isEmpty()
{
    if(front)                      //front ya rear kisi me NULL hai to Deque empty hoga so checking for front.
    return false;
    else
    return true;
}

Deque::~Deque()
{
    while(front)                // it wil deallocate all the memory
    DeleteAtFront();
}

node* Deque::getFront()
{
    return front;              // will return the address of front element
}

node* Deque::getRear()
{
    return rear;              // will return the address of rear element
}

void Deque::DeleteAtRear()
{
    node *r;
    if(rear)
    {
      r=rear;
      if(front=rear)
        rear=front=NULL;
      else
        {
            rear=rear->prev;
            rear->next=NULL;
        }
        delete r;
    }
}

void Deque::DeleteAtFront()
{
    node *r;
    if(front)
    {
      r=front;
      if(front=rear)
        front=rear=NULL;
      else
        {
            front=front->next;
            front->prev=NULL;
        }
        delete r;
    }
}

void Deque::InerstAtFront(int data)
{
    node *n=new node;
    node *t;
    n->item=data;
    n->prev=NULL;
    n->next=front;
    
    if(front)
      front->prev=n;
    else 
      rear=n;
    front=n;
    
}

void Deque::InerstAtRear(int data)
{
    node *n=new node;
    n->item=data;
    n->prev=rear;
    n->next=NULL;
    
    if(rear)
      rear->next=n;
    else 
      front=n;
    rear=n;
}


Deque::Deque()
{
    front=NULL;
    rear=NULL;
}

int main()
{
    cout<<"Hello World";

    return 0;
}