/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

struct node
{
    int item;
    node *next;
};

class CLL
{
  private:
  node *last;
  public:
  CLL();
  void InsertFirst(int);
  void InsertLast(int);
  node *SearchNode(int);
  void InsertAfter(node *,int);
  void DeletefirstNode();
  void DeletelastNode();
  void DeleteNode(node*);
  ~CLL();
};
CLL::~CLL()
{
    while(last)
    delete DeletefirstNode;
}
void CLL::DeleteNode(node* ptr)
{
    if(ptr)
    {
      node* t;
      t=last->next;
      while(t->next!=ptr)
        t=t->next;
      t->next=ptr->next;
      if(t==ptr)   // When single node present
        last=NULL;
      else if(last==ptr)   //When we have to delete last node in multi node system 
        last=t;          
      delete ptr;
    }  
}
void CLL::DeletelastNode()
{
  if(last)
  {
    node *t;
    t=last;
    while(t->next!=last)
        t=t->next;
    if(t==last)
    { //single node case
        delete last;
        last=NULL;
    }
    else
    {
        t->next=last->next;
        delete last;
        last=t;
    }
  }
}  


void CLL::DeletefirstNode()
{
    node *t;
    t=last->next;
    if(last->next==last)
      last=NULL;
    else
      last->next=t->next;
    delete t;
    
}

void CLL::InsertAfter(node *prt,int data)
{
    if(last)
    {
      node *n=new node;
      n->item=data;
      n->next=prt->next;
      prt->next=n;
      if(prt==last)
       last=n;
    }   
}

node *CLL::SearchNode(int data)
{
    node *t;
    if(last)
    {
        t=last->next;
        do
        {
            if(t->item==data)
            return t;
            t=t->next;
        }   
        while(t!=last->next);
    }
    return NULL;
}
void CLL::InsertFirst(int data)
{
    node *n=new node;
    n->item=data;
    if(last) // When list is not Empty
    { 
      n->next=last->next;   
      last->next=n;
    }
    else     // When list is Empty
    {
      n->next=n; 
      last=n;
    }
}

void CLL::InsertLast(int data)
{
    node *n=new node;
    n->item=data;
    if(last)
    {
       n->next=last->next;
       last->next=n;
       last=n;
    }
    else
    {
      n->next=n; 
      last=n;
    }
}


CLL::CLL()
{
    last=NULL;
}

int main()
{
    cout<<"Hello World";

    return 0;
}
