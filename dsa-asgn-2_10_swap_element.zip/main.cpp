/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void SwapIndex(int b[],int c,int a,int d)
{
    int temp=0;
    temp=b[a];
    b[a]=b[d];
    b[d]=temp;
    
    for(int i=0;i<c;i++)
    printf("%d",b[i]);
    
}

int main()
{
    int i,a[3],n,e,f;
    printf("Enter Number\n");
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0;i<3;i++)
    printf("%d",a[i]);
    printf("Enter first index to be switched");
    scanf("%d",&e);
    printf("Enter second index to be switched");
    scanf("%d",&f);
    SwapIndex(a,3,e,f);


    return 0;
}